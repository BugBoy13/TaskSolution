package net.eazypg.eazypgstaff.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import net.eazypg.eazypgstaff.Adapter.StaffProfileAdapter;
import net.eazypg.eazypgstaff.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class staff_fragment_profile extends Fragment {

    TabLayout tabLayout;
    ViewPager staffProfileViewPager;

    CircleImageView profile_image;
    TextView staffNameTextView,staffDesignationTextView,staffDateOfJoiningTextView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.staff_fragment_profile,container,false);

        tabLayout = view.findViewById(R.id.staffTabLayout);
        staffProfileViewPager = view.findViewById(R.id.staffProfileViewPager);
        staffNameTextView = view.findViewById(R.id.staffNameTextView);
        staffDesignationTextView = view.findViewById(R.id.staffDesignationTextView);
        staffDateOfJoiningTextView = view.findViewById(R.id.staffDateOfJoiningTextView);



        StaffProfileAdapter adapter = new StaffProfileAdapter(getActivity().getSupportFragmentManager());
        adapter.addFragment(new StaffDetailsFragment(), "Profile");
        adapter.addFragment(new StaffDocumentFragment(), "Documents");

        staffProfileViewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(staffProfileViewPager);
        tabLayout.setForegroundGravity(TabLayout.GRAVITY_FILL);




        return view;




        
    }
}
