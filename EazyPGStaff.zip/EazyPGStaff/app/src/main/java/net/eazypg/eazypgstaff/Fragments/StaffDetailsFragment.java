package net.eazypg.eazypgstaff.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;

import net.eazypg.eazypgstaff.R;

public class StaffDetailsFragment extends Fragment {


    EditText staffNameEditText, staffDesignationEditText, staffSalaryEditText, staffMobileEditText, staffCurrentAddressEditText;
    EditText staffPinEditText, staffCityEditText, staffStateEditText;
    EditText staffPermanentAddressEditText, staffPermanentCityEditText, staffPermanentStateEditText, staffPermanentPinEditText;
    EditText staffGovtIDEditText, staffNationalityEditText, staffMotherTongueEditText;
    EditText staffFatherNameEditText, staffFatherMobileEditText, staffFatherAddressEditText;
    EditText staffMotherNameEditText, staffMotherAddressEditText, staffMotherMobileEditText;
    EditText staffVehicleNoEditText, staffJobDurationEditText, staffWorkExperienceEditText, staffAltMobileNoEditText;
    EditText staffRefNameEditText, staffRefAddressEditText, staffRefMobileEditText;
    EditText staffRef2NameEditText, staffRef2AddressEditText, staffRef2MobileEditText;
    EditText staffBankACNoEditText, staffBankIFSCEditText, staffACHolderNameEditText, staffBankNameEditText;

    RadioGroup fatherMotherRadioGroup, fatherMother2RadioGroup;

    FloatingActionButton submit;

    String staffId, salary, contact, name, jobDesc, dateOfJoining;
    String currentAddress,currentAddressPin,currentAddressState,currentAddressCity;
    String permanentAddress,permanentAddressPin,permanenttAddressState,permanentAddressCity;
    String nationalityEditText, motherTongueEditText, aadharEditText;
    String fatherNameEditText, fatherOfficeAddressEditText, fatherMobileEditText;
    String motherNameEditText, motherOfficeAddressEditText,motherMobileEditText;
    String vehicleno,jobDuration,workExperience,altNumber;
    String reference1name,reference1Address,reference1number;
    String reference2name,reference2Address,reference2number;
    String bankAcNumber,bankIFSC,bankName,acHolderName;
    String reference1father, reference2father, reference1mother, reference2mother;




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.staff_details_fragment,container,false);

        staffNameEditText = view.findViewById(R.id.staffNameEditText);
        staffDesignationEditText = view.findViewById(R.id.staffDesignationEditText);
        staffSalaryEditText = view.findViewById(R.id.staffSalaryEditText);
        staffMobileEditText = view.findViewById(R.id.staffMobileEditText);
        staffCurrentAddressEditText = view.findViewById(R.id.staffCurrentAddressEditText);

        staffPinEditText = view.findViewById(R.id.staffPinEditText);
        staffCityEditText = view.findViewById(R.id.staffCityEditText);
        staffStateEditText = view.findViewById(R.id.staffStateEditText);

        staffPermanentAddressEditText = view.findViewById(R.id.staffPermanentAddressEditText);
        staffPermanentCityEditText = view.findViewById(R.id.staffPermanentCityEditText);
        staffPermanentStateEditText = view.findViewById(R.id.staffPermanentStateEditText);
        staffPermanentPinEditText = view.findViewById(R.id.staffPermanentPinEditText);

        staffGovtIDEditText = view.findViewById(R.id.staffGovtIDEditText);
        staffNationalityEditText = view.findViewById(R.id.staffNationalityEditText);
        staffMotherTongueEditText = view.findViewById(R.id.staffMotherTongueEditText);

        staffFatherNameEditText = view.findViewById(R.id.staffFatherNameEditText);
        staffFatherMobileEditText = view.findViewById(R.id.staffFatherMobileEditText);
        staffFatherAddressEditText = view.findViewById(R.id.staffFatherAddressEditText);

        staffMotherNameEditText = view.findViewById(R.id.staffMotherNameEditText);
        staffMotherAddressEditText = view.findViewById(R.id.staffMotherAddressEditText);
        staffMotherMobileEditText = view.findViewById(R.id.staffMotherMobileEditText);

        staffVehicleNoEditText = view.findViewById(R.id.staffVehicleNoEditText);
        staffJobDurationEditText = view.findViewById(R.id.staffJobDurationEditText);
        staffWorkExperienceEditText = view.findViewById(R.id.staffWorkExperienceEditText);
        staffAltMobileNoEditText = view.findViewById(R.id.staffAltMobileNoEditText);

        fatherMotherRadioGroup = view.findViewById(R.id.fatherMotherRadioGroup);

        staffRefNameEditText = view.findViewById(R.id.staffRefNameEditText);
        staffRefAddressEditText = view.findViewById(R.id.staffRefAddressEditText);
        staffRefMobileEditText = view.findViewById(R.id.staffRefMobileEditText);

        fatherMother2RadioGroup = view.findViewById(R.id.fatherMother2RadioGroup);

        staffRef2NameEditText = view.findViewById(R.id.staffRef2NameEditText);
        staffRef2AddressEditText = view.findViewById(R.id.staffRef2AddressEditText);
        staffRef2MobileEditText = view.findViewById(R.id.staffRef2MobileEditText);

        staffBankACNoEditText = view.findViewById(R.id.staffBankACNoEditText);
        staffBankIFSCEditText = view.findViewById(R.id.staffBankIFSCEditText);
        staffACHolderNameEditText = view.findViewById(R.id.staffACHolderNameEditText);
        staffBankNameEditText = view.findViewById(R.id.staffBankNameEditText);

        submit = view.findViewById(R.id.staffSaveButton);







        return view;
    }
}
