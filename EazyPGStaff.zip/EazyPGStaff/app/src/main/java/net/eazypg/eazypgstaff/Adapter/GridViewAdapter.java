package net.eazypg.eazypgstaff.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import net.eazypg.eazypgstaff.R;

public class GridViewAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private String[] gridTitleTextView;
    private String[] gridTitleInfoTextView;
    private int[] gridIconImageView;

    public GridViewAdapter(Context c,int[] gridIconImageView, String[] gridTitleTextView, String[] gridTitleInfoTextView){
        context = c;
        this.gridIconImageView = gridIconImageView;
        this.gridTitleTextView = gridTitleTextView;
        this.gridTitleInfoTextView = gridTitleInfoTextView;
    }




    @Override
    public int getCount() {
        return gridIconImageView.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(inflater == null){
            inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        }
        if(convertView == null) {
            convertView = inflater.inflate(R.layout.grid_view_custom_layout,null);

        }

        ImageView gridImageView = convertView.findViewById(R.id.gridIconImageView);
        TextView gridTextView = convertView.findViewById(R.id.gridTitleTextView);
        TextView gridDescriptionTextview = convertView.findViewById(R.id.gridTitleInfoTextView);


        gridImageView.setImageResource(gridIconImageView[position]);
        gridTextView.setText(gridTitleTextView[position]);
        gridDescriptionTextview.setText(gridTitleInfoTextView[position]);
        return convertView;
    }
}
