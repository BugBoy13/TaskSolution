package net.eazypg.eazypgstaff;

import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import net.eazypg.eazypgstaff.Adapter.FoodFragmentAdapter;
import net.eazypg.eazypgstaff.Adapter.FragmentAdapter;
import net.eazypg.eazypgstaff.Transformations.CubeInScalingTransformation;
import net.eazypg.eazypgstaff.Transformations.DepthViewPagerTransformation;
import net.eazypg.eazypgstaff.Transformations.ZoomOutTransformation;

public class FoodActivity extends AppCompatActivity {

    ImageView backButton;
    ViewPager viewPagerFoodContainer;
    TextView calenderDateTextView;
    ZoomOutTransformation zoomOutTransformation;
    ImageView editButtonImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        backButton = findViewById(R.id.backButton);
        viewPagerFoodContainer = findViewById(R.id.viewPagerFoodContainer);
        calenderDateTextView = findViewById(R.id.calenderDateTextView);
        editButtonImageView = findViewById(R.id.editButtonImageView);

        zoomOutTransformation = new ZoomOutTransformation();





        viewPagerFoodContainer.setAdapter(new FoodFragmentAdapter(getSupportFragmentManager()));
        viewPagerFoodContainer.setPageTransformer(true,zoomOutTransformation);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



    }


}
