package net.eazypg.eazypgstaff;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import net.eazypg.eazypgstaff.Adapter.FragmentAdapter;
import net.eazypg.eazypgstaff.Fragments.staff_fragment_home;
import net.eazypg.eazypgstaff.Fragments.staff_fragment_profile;
import net.eazypg.eazypgstaff.Fragments.staff_fragment_task;
import net.eazypg.eazypgstaff.Transformations.DepthViewPagerTransformation;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    ViewPager viewPagerContainer;
    DepthViewPagerTransformation depthViewPagerTransformation ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        viewPagerContainer = findViewById(R.id.viewPagerContainer);


        depthViewPagerTransformation = new DepthViewPagerTransformation();
        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);



        setupFm(getSupportFragmentManager(), viewPagerContainer);
        viewPagerContainer.setCurrentItem(0); //Set Current Item When Activity Start
        viewPagerContainer.setOnPageChangeListener(new PageChange());

        getSupportFragmentManager().beginTransaction().replace(R.id.viewPagerContainer,new staff_fragment_home()).commit();


    }




    public static void setupFm(FragmentManager fragmentManager, ViewPager viewPager){
        FragmentAdapter Adapter = new FragmentAdapter(fragmentManager);
        //Add All Fragment To List
        Adapter.add(new staff_fragment_home(), "Home");
        Adapter.add(new staff_fragment_task(), "Task");
        Adapter.add(new staff_fragment_profile(), "Profile");
        viewPager.setAdapter(Adapter);
    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

           // Fragment selectedFragment = null;

            switch (menuItem.getItemId()){

                case R.id.navigation_home:

                    viewPagerContainer.setCurrentItem(0);
                    viewPagerContainer.setPageTransformer(true, depthViewPagerTransformation);
                    return true;

                case R.id.navigation_task:
                    viewPagerContainer.setCurrentItem(1);
                    viewPagerContainer.setPageTransformer(true, depthViewPagerTransformation);
                    return true;

                case R.id.navigation_profile:
                    viewPagerContainer.setCurrentItem(2);
                    viewPagerContainer.setPageTransformer(true, depthViewPagerTransformation);
                    return true;
            }

            //getSupportFragmentManager().beginTransaction().replace(R.id.viewPagerContainer,selectedFragment).commit();

            return false;

        }

    };

    public class PageChange implements ViewPager.OnPageChangeListener {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {



        }


        @Override
        public void onPageSelected(int position) {
            switch (position) {
                case 0:
                    viewPagerContainer.setPageTransformer(true, depthViewPagerTransformation);
                    bottomNavigationView.setSelectedItemId(R.id.navigation_home);

                    break;
                case 1:
                    viewPagerContainer.setPageTransformer(true, depthViewPagerTransformation);
                    bottomNavigationView.setSelectedItemId(R.id.navigation_task);

                    break;
                case 2:
                    viewPagerContainer.setPageTransformer(true, depthViewPagerTransformation);
                    bottomNavigationView.setSelectedItemId(R.id.navigation_profile);

                    break;
            }
        }
        @Override
        public void onPageScrollStateChanged(int state) {


        }
    }

}
