package net.eazypg.eazypgstaff;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class AddingNewLeadsActivity extends AppCompatActivity {

    ImageView backButton;
    EditText tenantNameEditText, tenantPhoneEditText;
    RadioGroup genderRadioGroup, rentRadioGroup, roomRadioGroup;
    RadioButton genderRadioButton, rentRadioButton;
    RadioButton roomRadioButton;
    CheckBox acLeadCheckBox, messLeadCheckBox, washroomLeadCheckBox, wifiLeadCheckBox;
    Button addLeadButton, cancelLeadButton;
    TextView tenantGenderTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_new_leads);


        backButton = findViewById(R.id.backButton);
        tenantNameEditText = findViewById(R.id.tenantNameEditText);
        tenantPhoneEditText = findViewById(R.id.tenantPhoneEditText);
        genderRadioGroup = findViewById(R.id.genderRadioGroup);
        rentRadioGroup = findViewById(R.id.rentRadioGroup);
        roomRadioGroup = findViewById(R.id.roomRadioGroup);

        acLeadCheckBox = findViewById(R.id.acLeadCheckBox);
        messLeadCheckBox = findViewById(R.id.messLeadCheckBox);
        washroomLeadCheckBox = findViewById(R.id.washroomLeadCheckBox);
        wifiLeadCheckBox = findViewById(R.id.wifiLeadCheckBox);

        addLeadButton = findViewById(R.id.addLeadButton);
        cancelLeadButton = findViewById(R.id.cancelLeadButton);





        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
