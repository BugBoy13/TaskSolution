package net.eazypg.eazypgstaff;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.TimeUnit;

public class LoginActivity extends AppCompatActivity {

    EditText eazyPGIDEditText, phoneEditText;
    Button loginButton;

    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference, databaseReference1;

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallBacks;
    String phone;
    String eazyPGID;

    SharedPreferences sharedPreferences;
    int PGNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        eazyPGIDEditText = findViewById(R.id.eazyPGIDEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        loginButton = findViewById(R.id.loginButton);


        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();

        sharedPreferences = getSharedPreferences("PG", Context.MODE_PRIVATE);
        PGNumber = sharedPreferences.getInt("PGNumber", 1);


        if (firebaseUser != null) {

            startActivity(new Intent(LoginActivity.this, MainActivity.class));
        }


        loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                eazyPGID = eazyPGIDEditText.getText().toString();
                phone = phoneEditText.getText().toString();

                databaseReference = firebaseDatabase.getReference("EazyPGIDs/" + eazyPGID);

                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if (!dataSnapshot.exists()) {

                            Toast.makeText(LoginActivity.this, "This PG is Not Registered with EazyPG", Toast.LENGTH_SHORT).show();
                        } else {

                            String pgID = dataSnapshot.getValue(String.class);

                            char lastChar = eazyPGID.charAt(10);

                            switch (lastChar) {

                                case 'A':
                                    PGNumber = 1;
                                    break;
                                case 'B':
                                    PGNumber = 2;
                                    break;
                                case 'C':
                                    PGNumber = 3;
                                    break;
                                case 'D':
                                    PGNumber = 4;
                                    break;
                                case 'E':
                                    PGNumber = 5;
                                    break;
                                case 'F':
                                    PGNumber = 6;
                                    break;
                                case 'G':
                                    PGNumber = 7;
                                    break;
                                case 'H':
                                    PGNumber = 8;
                                    break;
                                case 'I':
                                    PGNumber = 9;
                                    break;
                                case 'J':
                                    PGNumber = 10;
                                    break;
                                case 'K':
                                    PGNumber = 11;
                                    break;
                                case 'L':
                                    PGNumber = 12;
                                    break;
                                case 'M':
                                    PGNumber = 13;
                                    break;
                                case 'N':
                                    PGNumber = 14;
                                    break;
                                case 'O':
                                    PGNumber = 15;
                                    break;
                                case 'P':
                                    PGNumber = 16;
                                    break;
                                case 'Q':
                                    PGNumber = 17;
                                    break;
                                case 'R':
                                    PGNumber = 18;
                                    break;
                                case 'S':
                                    PGNumber = 19;
                                    break;
                                case 'T':
                                    PGNumber = 20;
                                    break;
                                case 'U':
                                    PGNumber = 21;
                                    break;
                                case 'V':
                                    PGNumber = 22;
                                    break;
                                case 'W':
                                    PGNumber = 23;
                                    break;
                                case 'X':
                                    PGNumber = 24;
                                    break;
                                case 'Y':
                                    PGNumber = 25;
                                    break;
                                case 'Z':
                                    PGNumber = 26;
                                    break;
                            }

                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putInt("PGNumber", PGNumber);
                            editor.apply();


                            databaseReference1 = firebaseDatabase.getReference("PG/" + pgID + "/PG" + PGNumber + "/Staff");

                            Query query = databaseReference1.orderByChild("contact").equalTo(phone);

                            query.addValueEventListener(new ValueEventListener() {

                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                    if (!dataSnapshot.exists()) {

                                        Toast.makeText(LoginActivity.this, "You are not registered Staff", Toast.LENGTH_SHORT).show();
                                    } else {

                                        mCallBacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                                            @Override
                                            public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

                                                String code = phoneAuthCredential.getSmsCode();

                                                Toast.makeText(LoginActivity.this, "OTP Retrieved " + code, Toast.LENGTH_SHORT).show();

                                                firebaseAuth.signInWithCredential(phoneAuthCredential).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<AuthResult> task) {

                                                        if (task.isSuccessful()) {

                                                            startActivity(new Intent(LoginActivity.this, MainActivity.class ));

                                                        } else {

                                                            Toast.makeText(LoginActivity.this, "Verification failed", Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });

                                            }

                                            @Override
                                            public void onVerificationFailed(FirebaseException e) {

                                                Toast.makeText(LoginActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();

                                            }
                                        };

                                        PhoneAuthProvider.getInstance().verifyPhoneNumber("+91" + phone, 60, TimeUnit.SECONDS, LoginActivity.this, mCallBacks);

                                    }

                                }


                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });

    }
}
