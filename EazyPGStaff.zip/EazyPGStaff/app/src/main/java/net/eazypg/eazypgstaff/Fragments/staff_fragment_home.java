package net.eazypg.eazypgstaff.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import net.eazypg.eazypgstaff.Adapter.GridViewAdapter;
import net.eazypg.eazypgstaff.AddLeadsActivity;
import net.eazypg.eazypgstaff.CollectActivity;
import net.eazypg.eazypgstaff.FoodActivity;
import net.eazypg.eazypgstaff.R;

public class staff_fragment_home extends Fragment {

    GridView gridView;
    Intent intent;

    int[] gridIconImageView = { R.drawable.grid_collect_icon,
                                R.drawable.grid_bed_icon,
                                R.drawable.grid_leads_icon,
                                R.drawable.grid_complaints_icon,
                                R.drawable.grid_passbook_icon,
                                R.drawable.grid_food_icon,
                                R.drawable.grid_calender_icon,
                                R.drawable.grid_add_own_task_icon };


    String[] gridTitleTextView = {"Collect" ,
                                    "Rooms",
                                    "Leads",
                                    "Complaints",
                                    "Passbook",
                                    "Food",
                                    "Attendance",
                                    "Add own task"};


    String[] gridTitleInfoTextView = {"₹ 500 dues",
                                        "Vacant: 30",
                                        "Vacant bed: 15",
                                        "Unresolved: 12",
                                        "Expense|Payable",
                                        "Eating: 16",
                                        "P/A: 25/30",
                                        "Add note"};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.staff_fragment_home,container,false);

        gridView = view.findViewById(R.id.gridView);

        GridViewAdapter gridViewAdapter = new GridViewAdapter(view.getContext(),gridIconImageView,gridTitleTextView,gridTitleInfoTextView);
        gridView.setAdapter(gridViewAdapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                switch (position)
                {
                    case 0:
                        intent = new Intent(view.getContext(), CollectActivity.class);
                        break;

                    case 1:
                        Toast.makeText(view.getContext(), "you clicked on "+gridTitleTextView[position], Toast.LENGTH_SHORT).show();
                        break;

                    case 2:
                        intent = new Intent(view.getContext(), AddLeadsActivity.class);
                        break;

                    case 3:
                        Toast.makeText(view.getContext(), "you clicked on "+gridTitleTextView[position], Toast.LENGTH_SHORT).show();
                        break;

                    case 4:
                        Toast.makeText(view.getContext(), "you clicked on "+gridTitleTextView[position], Toast.LENGTH_SHORT).show();
                        break;

                    case 5:
                        intent = new Intent(view.getContext(), FoodActivity.class);
                        break;

                    case 6:
                        Toast.makeText(view.getContext(), "you clicked on "+gridTitleTextView[position], Toast.LENGTH_SHORT).show();
                        break;
                }
                startActivity(intent);
                Toast.makeText(view.getContext(), "you clicked on "+gridTitleTextView[position], Toast.LENGTH_SHORT).show();



            }
        });



        return view;




    }
}
