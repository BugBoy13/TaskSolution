package net.eazypg.eazypgstaff.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import net.eazypg.eazypgstaff.R;

public class StaffDocumentFragment extends Fragment {


    CardView aadharFrontCardView, aadharBackCardView, collegeIDFrontCardView, collegeIDBackCardView;

    ImageView aadharFrontImageView, aadharBackImageView, JobIdFrontImageView, JobIdBackImageView;

    TextView aadharFrontStatus, aadharBackStatus, JobIDFrontStatus, JobIDBackStatus;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.staff_documents_fragment,container,false);



        aadharFrontCardView = view.findViewById(R.id.aadharFrontCardView);
        aadharBackCardView = view.findViewById(R.id.aadharbackCardView);
        collegeIDFrontCardView = view.findViewById(R.id.collegeIDFrontCardView);
        collegeIDBackCardView = view.findViewById(R.id.collegeIDBackCardView);

        aadharFrontImageView = view.findViewById(R.id.aadharFrontImageView);
        aadharBackImageView = view.findViewById(R.id.aadharBackImageView);
        JobIdFrontImageView = view.findViewById(R.id.collegeIdFrontImageView);
        JobIdBackImageView = view.findViewById(R.id.collegeIdBackImageView);

        aadharFrontStatus = view.findViewById(R.id.aadharFrontStatus);
        aadharBackStatus = view.findViewById(R.id.aadharBackStatus);
        JobIDFrontStatus = view.findViewById(R.id.collegeIDFrontStatus);
        JobIDBackStatus = view.findViewById(R.id.collegeIDBackStatus);



        return view;
    }
}
