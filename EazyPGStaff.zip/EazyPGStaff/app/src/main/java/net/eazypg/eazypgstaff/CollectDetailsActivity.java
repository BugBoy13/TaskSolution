package net.eazypg.eazypgstaff;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class CollectDetailsActivity extends AppCompatActivity {


    TextView typeTextView, dateTextView, noOfTenantUnpaidTextView;
    TextView totalTextView, collectedTextView, duesTextView;
    ImageView typeImageView;

    ImageView backButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collect_details);


        typeTextView = findViewById(R.id.typeTextView);
        dateTextView = findViewById(R.id.dateTextView);
        typeImageView = findViewById(R.id.typeImageView);
        noOfTenantUnpaidTextView = findViewById(R.id.noOfTenantUnpaidTextView);
        totalTextView = findViewById(R.id.totalTextView);
        collectedTextView = findViewById(R.id.collectedTextView);
        duesTextView = findViewById(R.id.duesTextView);
        backButton = findViewById(R.id.backButton);















        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}
