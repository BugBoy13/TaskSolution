package net.eazypg.eazypgstaff;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class CollectActivity extends AppCompatActivity {

    CardView rentCardView,electricityBillCardView,wifiBillCardView,maintenanceBillCardView,otherBillCardView;
    ImageView backButton;
    TextView dateRentTextView, totalRentTextView,collectedRentTextView,duesRentTextView,dateElectricityTextView,totalElectricityTextView,collectedElectricityTextView,duesElectricityTextView;
    TextView dateWifiTextView,totalWifiTextView,collectedWifiTextView,duesWifiTextView,dateMaintenanceTextView,totalMaintenanceTextView,collectedMaintenanceTextView,duesMaintenanceTextView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collect);



        backButton = findViewById(R.id.backButton);

        rentCardView = findViewById(R.id.rentCardView);
        electricityBillCardView = findViewById(R.id.electricityBillCardView);
        wifiBillCardView = findViewById(R.id.wifiBillCardView);
        maintenanceBillCardView = findViewById(R.id.maintenanceBillCardView);
        otherBillCardView  = findViewById(R.id.otherBillCardView);

        dateRentTextView = findViewById(R.id.dateRentTextView);
        totalRentTextView = findViewById(R.id.totalRentTextView);
        collectedRentTextView = findViewById(R.id.collectedRentTextView);
        duesRentTextView = findViewById(R.id.duesRentTextView);

        dateElectricityTextView = findViewById(R.id.dateElectricityTextView);
        totalElectricityTextView = findViewById(R.id.totalElectricityTextView);
        duesElectricityTextView = findViewById(R.id.duesElectricityTextView);
        collectedElectricityTextView = findViewById(R.id.collectedElectricityTextView);


        dateWifiTextView = findViewById(R.id.dateWifiTextView);
        totalWifiTextView = findViewById(R.id.totalWifiTextView);
        collectedWifiTextView = findViewById(R.id.collectedWifiTextView);
        duesWifiTextView  = findViewById(R.id.duesWifiTextView);


        dateMaintenanceTextView = findViewById(R.id.dateMaintenanceTextView);
        totalMaintenanceTextView = findViewById(R.id.totalMaintenanceTextView);
        collectedMaintenanceTextView = findViewById(R.id.collectedMaintenanceTextView);
        duesMaintenanceTextView = findViewById(R.id.duesMaintenanceTextView);




        rentCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollectActivity.this,CollectDetailsActivity.class);
                startActivity(intent);
            }
        });


        electricityBillCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollectActivity.this,CollectDetailsActivity.class);
                startActivity(intent);
            }
        });


        wifiBillCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollectActivity.this,CollectDetailsActivity.class);
                startActivity(intent);
            }
        });


        maintenanceBillCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollectActivity.this,CollectDetailsActivity.class);
                startActivity(intent);
            }
        });


        otherBillCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollectActivity.this,CollectDetailsActivity.class);
                startActivity(intent);
            }
        });





        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
