package net.eazypg.eazypgstaff;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class AddLeadsActivity extends AppCompatActivity {


    ImageView backButton,addLeadsPlusImageView;
    TextView addLeadsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_leads);


        addLeadsTextView = findViewById(R.id.addLeadsTextView);
        addLeadsPlusImageView = findViewById(R.id.addLeadsPlusImageView);
        backButton = findViewById(R.id.backButton);

        addLeadsPlusImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddLeadsActivity.this, AddingNewLeadsActivity.class);
                startActivity(intent);
            }
        });


        addLeadsTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddLeadsActivity.this, AddingNewLeadsActivity.class);
                startActivity(intent);
            }
        });




        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
