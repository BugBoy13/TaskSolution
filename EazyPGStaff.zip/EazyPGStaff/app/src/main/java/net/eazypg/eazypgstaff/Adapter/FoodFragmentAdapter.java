package net.eazypg.eazypgstaff.Adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import net.eazypg.eazypgstaff.Fragments.Food_fragment_friday;
import net.eazypg.eazypgstaff.Fragments.Food_fragment_monday;
import net.eazypg.eazypgstaff.Fragments.Food_fragment_saturday;
import net.eazypg.eazypgstaff.Fragments.Food_fragment_sunday;
import net.eazypg.eazypgstaff.Fragments.Food_fragment_thursday;
import net.eazypg.eazypgstaff.Fragments.Food_fragment_tuesday;
import net.eazypg.eazypgstaff.Fragments.Food_fragment_wednesday;

public class FoodFragmentAdapter extends FragmentPagerAdapter {




    public FoodFragmentAdapter(FragmentManager manager) {

        super(manager);
    }

  /*  public void add(Fragment Frag, String Title) {

        Fragment.add(Frag);
        NamePage.add(Title);

    }*/

    @Override
    public Fragment getItem(int position) {

        switch (position)
        {
            case 0:
                return new Food_fragment_monday();
            case 1:
                return new Food_fragment_tuesday();
            case 2:
                return new Food_fragment_wednesday();

            case 3:
                return new Food_fragment_thursday();

            case 4:
                return new Food_fragment_friday();

            case 5:
                return new Food_fragment_saturday();

            case 6:
                return new Food_fragment_sunday();
        }
        return null; //does not happen

    }

 /*   @Override
    public CharSequence getPageTitle(int position) {

        return NamePage.get(position);

    }*/

    @Override
    public int getCount() {
        return 7;
    }
}
